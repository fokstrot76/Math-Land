﻿/** \Author Omar Ibrahim Abou Kanour: B00066509 
 * This method is used to change object proporities and determine which level to laod */
using UnityEngine;
using System.Collections;

public class ChangeColor : MonoBehaviour {

	public int levelToLoadOnClick=0;
	private void OnMouseEnter()
	{
		guiText.fontSize= 58;
		guiText.color = Color.red;

	}
	/** when the mouse exist the object area */
	private void OnMouseExit()
	{
		guiText.fontSize= 42;
		guiText.color = Color.black;
	}
	/** when mouse is relased */
	private void OnMouseUp()
	{
		Application.LoadLevel (levelToLoadOnClick);
	}
}
